<?php

namespace Mpdf\Tag;

class VarTag extends InlineTag
{


}
